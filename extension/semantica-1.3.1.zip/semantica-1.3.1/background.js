// Se ejecuta al instalar la extensión: habilita el panel lateral
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setOptions({
    path: "panel.html",
    enabled: true
  });
});

// Se ejecuta al hacer clic en el ícono de la extensión
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Nuevo: Limpia los errores al cambiar de URL o recargar
const panelPorts = [];

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "panel") {
    panelPorts.push(port);

    port.onDisconnect.addListener(() => {
      const index = panelPorts.indexOf(port);
      if (index !== -1) panelPorts.splice(index, 1);
    });
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
 if (changeInfo.status === 'complete') {
    // Limpiar errores visuales en la página
    chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.sendMessage(tabId, { tipo: "eliminarResaltado" 

  });

    // Borrar los errores guardados
   chrome.storage.local.remove('erroresWcag', () => {
    console.log('Storage borrado por cambio de pestaña activa');
  });

    // (Opcional: si querés mantener también la conexión con el panel)
    panelPorts.forEach(port => {
    port.postMessage({ tipo: "limpiarPanel" });
  });
});
}});
