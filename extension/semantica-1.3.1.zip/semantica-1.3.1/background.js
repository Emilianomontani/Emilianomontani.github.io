// Se ejecuta al instalar la extensión: habilita el panel lateral
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setOptions({
    path: "panel.html",
    enabled: true
  });
});

// Se ejecuta al hacer clic en el ícono de la extensión
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Conexión con el panel lateral
const panelPorts = [];

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "panel") {
    panelPorts.push(port);

    port.onDisconnect.addListener(() => {
      const index = panelPorts.indexOf(port);
      if (index !== -1) panelPorts.splice(index, 1);
    });
  }
});

// Limpieza al recargar o cambiar de URL
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete') {
    chrome.tabs.sendMessage(tabId, { tipo: "eliminarResaltado" });
    chrome.storage.local.remove('erroresWcag', () => {
      console.log('Storage borrado por cambio de URL');
    });
    panelPorts.forEach(port => {
      port.postMessage({ tipo: "limpiarPanel" });
    });
  }
});

// Limpieza al cambiar de pestaña activa
chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.sendMessage(tabId, { tipo: "eliminarResaltado" });
  chrome.storage.local.remove('erroresWcag', () => {
    console.log('Storage borrado por cambio de pestaña');
  });
  panelPorts.forEach(port => {
    port.postMessage({ tipo: "limpiarPanel" });
  });
});


// Si usás puerto
if (panelPort) panelPort.postMessage({ tipo: 'limpiarPanel' });

// Si usás sendMessage
chrome.runtime.sendMessage({ tipo: 'limpiarPanel' });
