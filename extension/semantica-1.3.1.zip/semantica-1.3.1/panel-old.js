const idioma = navigator.language.startsWith('es') ? 'es' : 'en';

fetch(`lang/${idioma}.json`)
  .then(res => res.json())
  .then(traducciones => {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const clave = el.getAttribute('data-i18n');
      if (traducciones[clave]) {
        el.textContent = traducciones[clave];
      }
    });
  });

window.addEventListener('DOMContentLoaded', () => {
    const verifyButton = document.getElementById('verify');
    const copyButton = document.getElementById('copy');
    const resaltarCheckbox = document.getElementById('resaltarCheckbox');

    const port = chrome.runtime.connect({ name: "panel" });

    port.onMessage.addListener((msg) => {
    if (msg.tipo === "limpiarPanel") {
        const contenedor = document.getElementById('errores');
        if (contenedor) contenedor.innerHTML = '';

        const filtros = document.querySelectorAll('#filtros input[type="checkbox"]');
        filtros.forEach(cb => cb.checked = true);
    }
    });

    // Almacena los errores
    chrome.storage.local.get('erroresWcag', (data) => {
        if (data.erroresWcag && Array.isArray(data.erroresWcag)) {
            mostrarErroresEnPopup(data.erroresWcag);

            const checkbox = document.getElementById('resaltarCheckbox');
            if (checkbox && checkbox.checked) {
                resaltarErroresEnPagina(data.erroresWcag);
            }
        }
    });

    // Activa el filtrado al cambiar los checkbox
    const botonFiltrar = document.getElementById('aplicarFiltro');
    const filtros = document.querySelectorAll('#filtros input[type="checkbox"]');
    botonFiltrar.addEventListener('click', aplicarFiltroErrores);



    function aplicarFiltroErrores() {
        const activos = Array.from(filtros)
            .filter(cb => cb.checked)
            .map(cb => cb.value);

        const errores = document.querySelectorAll('#errores li');

        errores.forEach(li => {
            const tipo = li.dataset.tipoError;
            if (!tipo || activos.includes(tipo)) {
                li.style.display = '';
            } else {
                li.style.display = 'none';
            }
        });
    }


    // Esta función limpia lo almacenado
    const limpiar = document.getElementById('limpiar');

    limpiar.addEventListener('click', () => {
        // 1. Limpiar storage
        chrome.storage.local.remove('erroresWcag', () => {
            console.log("Errores eliminados del storage");
        });

        // 2. Limpiar interfaz
        const contenedorErrores = document.getElementById('errores');
        contenedorErrores.innerHTML = '';

        // 3. Eliminar resaltados en la página
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                tipo: "eliminarResaltado"
            });
        });

        // 4. vacía la casilla si se dejó presionada. 
        const checkbox = document.getElementById('resaltarCheckbox');
        if (checkbox) {
            checkbox.checked = false;
        }
    });


    verifyButton.addEventListener('click', ejecutarVerificacion);
    verifyButton.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            ejecutarVerificacion();
        }
    });

    copyButton.addEventListener('click', copiarErrores);
    copyButton.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            copiarErrores();
        }
    });

    resaltarCheckbox.addEventListener("change", function () {
        const activo = this.checked;
        const elementIdsToHighlight = obtenerElementIdsParaResaltar();
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                tipo: "resaltarElementosError",
                elementIds: elementIdsToHighlight,
                activar: activo
            });
        });
    });

    function obtenerElementIdsParaResaltar() {
        const listItems = document.querySelectorAll('#errores li[data-wcag-error-id]');
        const singleIds = Array.from(listItems).map(item => item.dataset.wcagErrorId);

        const listItemsMultiple = document.querySelectorAll('#errores li[data-wcag-error-ids]');
        const multipleIds = Array.from(listItemsMultiple).reduce((acc, item) => {
            const ids = JSON.parse(item.dataset.wcagErrorIds);
            return acc.concat(ids);
        }, []);

        return singleIds.concat(multipleIds);
    }

function ejecutarVerificacion() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      function: verificarAccesibilidad
    }, (results) => {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError);
        return;
      }

      if (results && results[0] && results[0].result) {
        const errores = results[0].result;
        mostrarErroresEnPopup(errores);

        // ✅ Recargar traducciones después de mostrar errores
        aplicarTraduccionesDinamicas();

        // ✅ Guardar en storage
        chrome.storage.local.set({ erroresWcag: errores }, () => {
          console.log("Errores guardados en storage");
        });
      }
    });
  });

  mostrarEncabezadoResultados();
}



    function mostrarEncabezadoResultados() {
        let encabezado = document.getElementById('results');
        encabezado.style.display = 'block';
        encabezado.setAttribute('role', 'status');
        encabezado.setAttribute('aria-live', 'polite');
        encabezado.setAttribute('data-i18n', 'results');
        setTimeout(() => {
            encabezado.textContent = "RESULTADOS:";
        }, 50);
    }

    function copiarErrores() {
        const listaErrores = document.querySelectorAll('#errores li');
        const encabezados = document.querySelectorAll('#errores h3');
        if (listaErrores.length === 0) {
            alert("No hay errores para copiar.");
            return;
        }
        let texto = "";
        encabezados.forEach(h3 => {
            texto += h3.textContent + "\n";
        });
        listaErrores.forEach(li => {
            texto += li.textContent + "\n";
        });
        navigator.clipboard.writeText(texto).then(() => {
            alert("Errores copiados al portapapeles.");
        }).catch(err => {
            console.error("Error al copiar:", err);
        });
    }
});

function aplicarFiltroErrores() {
    const activos = Array.from(filtros)
        .filter(cb => cb.checked)
        .map(cb => cb.value);

    const errores = document.querySelectorAll('#errores li');

    errores.forEach(li => {
        const tipo = li.dataset.tipoError;
        if (!tipo || activos.includes(tipo)) {
            li.style.display = '';
        } else {
            li.style.display = 'none';
        }
    });
}

function verificarAccesibilidad() {
    let erroresDetectados = [];

    function buscarEtiquetasP() {
        let parrafos = document.querySelectorAll('p');
        const parrafosVaciosEncontrados = [];
        const elementIdsParrafosVacios = [];

        parrafos.forEach(parrafo => {
            // Normaliza el contenido HTML para evitar problemas con espacios en blanco extras alrededor de &nbsp;
            // y para asegurar que la regex funcione correctamente.
            const cleanedInnerHTML = parrafo.innerHTML.trim();

            // Regex para detectar uno o más '&nbsp;' seguidos.
            // El '\s*' al principio y al final permite espacios en blanco adicionales
            // que no sean &nbsp; pero que igualmente resultan en un párrafo visualmente vacío.
            const nbspRegex = /^(\s*&nbsp;)+\s*$/i; 

            if (cleanedInnerHTML === '' || nbspRegex.test(cleanedInnerHTML)) {
                const errorId = Math.random().toString(36).substring(7);
                parrafo.dataset.wcagErrorId = errorId;
                parrafosVaciosEncontrados.push(`Error: Etiqueta <p> vacía o con &nbsp;`);
                elementIdsParrafosVacios.push(errorId);
            }
        });

        if (parrafosVaciosEncontrados.length > 0) {
            erroresDetectados.push({
                titulo: "Párrafos vacíos o con &nbsp;",
                errores: [`Se encontraron ${parrafosVaciosEncontrados.length} párrafos vacíos en la página.`].concat(parrafosVaciosEncontrados.map((error, index) => `${error} #${index + 1}`)),
                elementIds: elementIdsParrafosVacios
            });
        }
    }

    function contarEtiquetas() {
        let etiquetasProhibidas = ['b', 'u', 'br', 'font', 's', 'small', 'i'];
        etiquetasProhibidas.forEach(etiqueta => {
            let elementos = Array.from(document.querySelectorAll(etiqueta))
                .filter(elemento =>
                    elemento.getAttribute('role') !== 'presentation' &&
                    elemento.getAttribute('aria-hidden') !== 'true'
                );

            const cantidad = elementos.length;
            if (cantidad > 0) {
                const erroresIndividuales = [];
                const elementIdsIndividuales = [];
                elementos.forEach(elemento => {
                    const errorId = Math.random().toString(36).substring(7);
                    elemento.dataset.wcagErrorId = errorId;
                    erroresIndividuales.push(`Error: Etiqueta <${etiqueta}> encontrada.`);
                    elementIdsIndividuales.push(errorId);
                });
                erroresDetectados.push({
                    titulo: `Etiquetas <${etiqueta}> encontradas`,
                    errores: [`Se encontraron ${cantidad} etiquetas <${etiqueta}> en la página.`].concat(erroresIndividuales),
                    elementIds: elementIdsIndividuales
                });
            }
        });
    }

    function buscarDivsSinEtiquetaInterior() {
    // La línea de traducciones ha sido eliminada.
    let divs = Array.from(document.getElementsByTagName('div'));
    const divsConError = [];
    const rolesPermitidos = [
        'button', 'link', 'checkbox', 'radio', 'switch', 'tab', 'menuitem',
        'menuitemcheckbox', 'menuitemradio', 'option', 'treeitem', 'gridcell',
        'columnheader', 'rowheader', 'slider', 'spinbutton', 'listbox',
        'radiogroup', 'toolbar', 'menubar', 'menu', 'tablist', 'tree', 'grid',
        'table', 'row', 'group', 'tooltip', 'dialog', 'alertdialog',
        'article', 'note', 'region', 'rowgroup', 'cell'
    ];

    let erroresIds = [];

    divs.forEach((div, index) => {
        let tieneTextoDirectoEncontrado = false;

        for (const node of div.childNodes) {
            if (node.nodeType === Node.TEXT_NODE) {
                const trimmedText = node.textContent.trim();
                if (trimmedText.length > 0) {
                    tieneTextoDirectoEncontrado = true;
                    break;
                }
            }
        }

        const divRole = div.getAttribute('role');
        const tieneRolDirectoPermitido = divRole && rolesPermitidos.includes(divRole.toLowerCase());

        // estaDentroDeElementoPermitido también detecta si el div está dentro de un <p>
        let estaDentroDeElementoPermitido = div.closest('button, h1, h2, h3, h4, h5, h6, p');

        if (tieneTextoDirectoEncontrado && !tieneRolDirectoPermitido && !estaDentroDeElementoPermitido) {
            const errorId = Math.random().toString(36).substring(7);
            div.dataset.wcagErrorId = errorId;

            // Mensaje hardcodeado en español
            const mensajeIndividual = `Error: div con contenido directo no permitido #${index + 1}: ${div.outerHTML.substring(0, 100)}`;
            divsConError.push(mensajeIndividual);
            erroresIds.push(errorId);
        }
    });

    if (divsConError.length > 0) {
        // Mensaje de resumen hardcodeado en español
        const resumenMensaje = `Se encontraron ${divsConError.length} elementos <div> con texto directo no permitido.`;

        erroresDetectados.push({
            titulo: "Divs con contenido directo no permitido",
            errores: [resumenMensaje].concat(divsConError),
            elementIds: erroresIds
        });
    }
}


    function buscarSpansSinCondicion() {
        let spans = Array.from(document.getElementsByTagName('span'));
        const spansConError = [];
        const erroresIds = [];

        const rolesPermitidosSpan = [
            'button', 'link', 'checkbox', 'radio', 'switch', 'tab', 'menuitem',
            'menuitemcheckbox', 'menuitemradio', 'option', 'treeitem', 'slider',
            'spinbutton', 'listbox', 'radiogroup', 'toolbar', 'menubar', 'menu',
            'tablist', 'tree', 'tooltip', 'status', 'alert', 'log', 'marquee',
            'timer', 'term', 'definition', 'caption', 'figurecaption', 'label',
            'legend', 'strong', 'emphasis', 'code', 'suggestion', 'insertion',
            'deletion', 'note', 'cell', 'columheader'
        ];

        spans.forEach((span, index) => {
            let padrePermitido = ['p', 'a', 'button', 'ul', 'li', 'th', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'input', 'label', 'summary'].includes(span.parentElement?.tagName?.toLowerCase());
            let contenidoHTML = span.innerHTML.trim();
            let interiorComienzaConTexto = contenidoHTML !== '' && contenidoHTML[0] !== '<';
            let estaDentroDeElementoPermitido = span.closest('a, button, h1, h2, h3, h4, h5, h6, li, input, label');

            const spanRole = span.getAttribute('role');
            const tieneRolDirectoPermitido = spanRole && rolesPermitidosSpan.includes(spanRole.toLowerCase());

            if (!padrePermitido && interiorComienzaConTexto && !estaDentroDeElementoPermitido && !tieneRolDirectoPermitido && spanRole?.toLowerCase() !== 'heading') {
                const errorId = Math.random().toString(36).substring(7);
                span.dataset.wcagErrorId = errorId;
                spansConError.push(`Error: span con contenido directo no permitido #${index + 1}: ${span.outerHTML.substring(0, 100)}`);
                erroresIds.push(errorId);
            }
        });

        if (spansConError.length > 0) {
            // --- CAMBIO AQUÍ: Añadir el resumen como el primer elemento del array 'errores' ---
            const resumenMensaje = `Se encontraron ${spansConError.length} elementos <span> con contenido directo no permitido (fuera de un contexto semántico válido).`;
            erroresDetectados.push({
                titulo: "Spans con contenido directo no permitido",
                errores: [resumenMensaje].concat(spansConError), // El resumen va primero
                elementIds: erroresIds
            });
        }
    }


    function listarListasVacias() {
        let listas = document.querySelectorAll('ul, ol');
        const listasVaciasEncontradas = [];
        const listasVaciasIds = [];

        listas.forEach(lista => {
            let estilo = window.getComputedStyle(lista);
            if (lista.children.length === 0 && estilo.display !== "none") {
                const errorId = Math.random().toString(36).substring(7);
                lista.dataset.wcagErrorId = errorId;
                listasVaciasEncontradas.push(`Error: Se encontró una lista <ol> o <ul> vacía.`);
                listasVaciasIds.push(errorId);
            }
        });

        if (listasVaciasEncontradas.length > 0) {
            erroresDetectados.push({
                titulo: "Listas vacías detectadas",
                errores: [`Se encontraron ${listasVaciasEncontradas.length} listas vacías en la página.`].concat(listasVaciasEncontradas.map((error, index) => `${error} #${index + 1}`)),
                elementIds: listasVaciasIds
            });
        }
    }

    function verificarEncabezadosVacios() {
        let encabezados = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
        const todosLosEncabezadosVaciosErrores = [];
        const todosLosEncabezadosVaciosIds = [];

        encabezados.forEach(nivel => {
            let elementos = document.querySelectorAll(nivel);
            // Mantener estos arrays temporales para recolectar por nivel, como lo tenías.
            const encabezadosVaciosDeNivelErrores = [];
            const encabezadosVaciosDeNivelIds = [];

            // ¡CORRECCIÓN AQUÍ! Usar 'elementos' en lugar de 'elements'
            elementos.forEach((h, index) => {
                let contenido = h.innerText.trim();
                let tieneDisplayNone = window.getComputedStyle(h).display === 'none';
                let tieneImagenConAlt = false;
                let enlaces = h.querySelectorAll('a');
                enlaces.forEach(a => {
                    let imagen = a.querySelector('img');
                    if (imagen && imagen.alt.trim() !== '') {
                        tieneImagenConAlt = true;
                    }
                });
                let contieneSpan = h.querySelector('span') !== null;

                // Verificar si está dentro de un <details> cerrado
                const parentDetails = h.closest('details');
                const estaDentroDeDetailsCerrado = parentDetails && !parentDetails.open;

                if (
                    !tieneDisplayNone &&
                    !tieneImagenConAlt &&
                    !contieneSpan &&
                    contenido === '' &&
                    !estaDentroDeDetailsCerrado
                ) {
                    const errorId = Math.random().toString(36).substring(7);
                    h.dataset.wcagErrorId = errorId;
                    // Pushear a los arrays temporales de este nivel
                    encabezadosVaciosDeNivelErrores.push(`Error: Encabezado <${nivel}> vacío.`);
                    encabezadosVaciosDeNivelIds.push(errorId);
                }
            });

            // Al final del bucle de cada nivel, concatenar los errores encontrados
            // a los arrays totales.
            todosLosEncabezadosVaciosErrores.push(...encabezadosVaciosDeNivelErrores);
            todosLosEncabezadosVaciosIds.push(...encabezadosVaciosDeNivelIds);
        });

        if (todosLosEncabezadosVaciosErrores.length > 0) {
            erroresDetectados.push({
                titulo: "Encabezados vacíos detectados",
                errores: [`Se encontraron ${todosLosEncabezadosVaciosErrores.length} encabezados vacíos en la página.`].concat(todosLosEncabezadosVaciosErrores.map((error, index) => `${error} #${index + 1}`)),
                elementIds: todosLosEncabezadosVaciosIds
            });
        }
    }

    function verificarEncabezadosTablaVacios() {
        let ths = document.querySelectorAll('th');
        const thsVaciosErrores = [];
        const thsVaciosIds = [];

        ths.forEach((th, index) => {
            const estilo = window.getComputedStyle(th);
            const estaOculto = estilo.display === 'none' || th.getAttribute('aria-hidden') === 'true';

            if (!estaOculto && th.innerText.trim() === '') {
                const errorId = Math.random().toString(36).substring(7);
                th.dataset.wcagErrorId = errorId;
                thsVaciosErrores.push(`Error: Encabezado de tabla <th> vacío en la posición ${index + 1}`);
                thsVaciosIds.push(errorId);
            }
        });

        if (thsVaciosErrores.length > 0) {
            erroresDetectados.push({
                titulo: "Encabezados de tabla vacíos",
                errores: [`Se encontraron ${thsVaciosErrores.length} encabezados de tabla vacíos en la página.`].concat(thsVaciosErrores),
                elementIds: thsVaciosIds
            });
        }
    }

    function verificarH1Unico() {
        let h1s = Array.from(document.getElementsByTagName('h1'));
        let h1sVisibles = h1s.filter(h1 => window.getComputedStyle(h1).display !== 'none');
        const cantidadH1Visibles = h1sVisibles.length;

        if (cantidadH1Visibles > 1) {
            const h1Errores = [];
            const h1Ids = [];
            const h1Tipos = [];

            h1sVisibles.forEach((h1) => {
                const errorId = Math.random().toString(36).substring(7);
                h1.dataset.wcagErrorId = errorId;
                h1Errores.push(`Error: Se encontró un <h1> visible adicional.`);
                h1Ids.push(errorId);
                h1Tipos.push('hh'); // ✅ diferenciación para filtros
            });

            erroresDetectados.push({
                titulo: "<h1> único",
                errores: [`Se encontraron ${cantidadH1Visibles} etiquetas <h1> visibles en la página (se espera solo una).`].concat(h1Errores),
                elementIds: h1Ids,
                tipos: h1Tipos
            });
        }
    }


    buscarDivsSinEtiquetaInterior();
    buscarSpansSinCondicion();
    buscarEtiquetasP();
    contarEtiquetas();
    verificarEncabezadosVacios();
    verificarH1Unico();
    listarListasVacias();
    verificarEncabezadosTablaVacios();

    return erroresDetectados;
}

function mostrarErroresEnPopup(errores) {
    let contenedorErrores = document.getElementById('errores');
    contenedorErrores.innerHTML = '';

    if (errores.length > 0) {
        errores.forEach(error => {
            // 'error' aquí es el objeto { titulo, errores, elementIds }
            // que viene de 'erroresDetectados'

            // Verifica que 'error.errores' sea un array y no esté vacío
            if (error.errores && Array.isArray(error.errores) && error.errores.length > 0) {
                const bloque = document.createElement('details'); // Este es 'bloque'
                bloque.open = false; // Asegura que se cargue cerrado

                // --- Lógica para el elemento <summary> (el título colapsable) ---
                const resumen = document.createElement('summary');
                // El primer elemento de error.errores es el mensaje de resumen (ej. "Se encontraron X párrafos...")
                const mensajeResumenDelError = error.errores[0]; 
                resumen.textContent = mensajeResumenDelError;
                resumen.classList.add('number__message'); // Tu clase para estilizar
                bloque.appendChild(resumen);

                // --- Lógica para el contenido detallado (la lista de errores individuales) ---
                const lista = document.createElement('ul');
                lista.classList.add('error-details-list'); // Añadir una clase para estilizar la lista

                // OBTENER LOS MENSAJES DE ERROR INDIVIDUALES:
                // Usamos slice(1) para obtener todos los elementos excepto el primero (el resumen).
                // Esta es la variable que debes usar en el siguiente forEach.
                const erroresIndividualesParaListar = error.errores.slice(1);

                // Iterar sobre los errores INDIVIDUALES para crear los <li>
                erroresIndividualesParaListar.forEach((errorMsg, index) => { // ¡CAMBIO AQUÍ! Usamos erroresIndividualesParaListar
                    let li = document.createElement('li');

                    const icon = document.createElement('i');
                    icon.classList.add('fas', 'fa-search'); // Asumiendo que tienes Font Awesome
                    icon.style.marginRight = '8px';

                    const textNode = document.createTextNode(errorMsg);
                    li.appendChild(icon);
                    li.appendChild(textNode);
                    li.classList.add('error'); // Clase para el estilo de cada li de error
                    li.classList.add('pointer'); // Añadido para el cursor de mano

                    // Obtener el ID del elemento original asociado a este error
                    // El 'index' aquí se corresponde con el índice en 'elementIds' porque 'erroresIndividualesParaListar'
                    // se "alinea" con 'elementIds' al quitar el resumen.
                    const errorId = error.elementIds && error.elementIds[index]; 
                    if (errorId) {
                        li.dataset.wcagErrorId = errorId;

                        // Lógica para determinar el 'tag' del error
                        const tag =
                            errorMsg.includes('visible adicional') ? 'hh' :
                            errorMsg.includes('<p>') ? 'p' :
                            errorMsg.includes('<div') ? 'div' :
                            errorMsg.includes('<span') ? 'span' :
                            errorMsg.includes('<b>') ? 'b' :
                            errorMsg.includes('<i>') ? 'i' :
                            errorMsg.includes('<s>') ? 's' :
                            errorMsg.includes('<u>') ? 'u' :
                            errorMsg.includes('<ul>') || errorMsg.includes('<ol>') || errorMsg.includes('<ol> o <ul>') ? 'ul' :
                            errorMsg.match(/<h[1-6]>/) ? 'h' :
                            errorMsg.includes('<br') ? 'br' :
                            errorMsg.includes('<small>') ? 'small' :
                            errorMsg.includes('<font>') ? 'font' :
                            errorMsg.includes('<th>') ? 'th' : '';

                        if (tag) {
                            li.dataset.tipoError = tag;
                        }

                        // Event listener para navegar al elemento
                        li.addEventListener('click', () => {
                            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                                chrome.tabs.sendMessage(tabs[0].id, {
                                    tipo: "navegarAlElemento",
                                    errorId: errorId
                                });
                            });
                        });
                    }

                    lista.appendChild(li);
                });

                bloque.appendChild(lista); // Añade la lista completa al <details>
                contenedorErrores.appendChild(bloque); // Añade el <details> al contenedor principal
            }
        });
    } else {
        contenedorErrores.innerHTML = '<li data-i18n="exito_no_errores" class="mensaje-exito">✅Éxito: No se encontraron errores.</li>';
    }
}

function aplicarTraduccionesDinamicas() {
  fetch(`lang/${idioma}.json`)
    .then(res => res.json())
    .then(traducciones => {
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const clave = el.getAttribute('data-i18n');
        if (traducciones[clave]) {
          el.textContent = traducciones[clave];
        }
      });
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.tipo === "limpiarPanel") {
    const contenedor = document.getElementById('errores');
    if (contenedor) {
      contenedor.innerHTML = '';
    }

    // También desmarcá todas las casillas de filtro, si querés
    const filtros = document.querySelectorAll('#filtros input[type="checkbox"]');
    filtros.forEach(cb => cb.checked = true);
  }
});
