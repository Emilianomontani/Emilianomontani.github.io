chrome.runtime.onMessage.addListener((mensaje, sender, sendResponse) => {
    if (mensaje.tipo === "navegarAlElemento" && mensaje.errorId) {
        const selector = `[data-wcag-error-id="${mensaje.errorId}"]`;
        const elemento = document.querySelector(selector);

        if (!elemento) {
            alert("Elemento no encontrado. ¿Quizás fue eliminado o está fuera del DOM?");
            return;
        }

        const estilo = window.getComputedStyle(elemento);
        const visible = estilo.display !== "none" && estilo.visibility !== "hidden";

        if (!visible) {
            alert("El elemento existe pero está oculto (por display:none o visibility:hidden).");
            return;
        }

        const tag = elemento.tagName.toLowerCase();
        const esEncabezado = /^h[1-6]$/.test(tag);
        const esLista = tag === 'ul' || tag === 'ol';
        const esParrafo = tag === 'p';
        const esBr = tag === 'br';

        const estaVacio = elemento.innerText.trim() === '' && elemento.children.length === 0;

        if (esBr || (estaVacio && (esParrafo || esEncabezado || esLista))) {
            const marcador = document.createElement('span');
            marcador.textContent = '⬅︎';
            marcador.style.background = '#ff7a19';
            marcador.style.color = '#fff';
            marcador.style.padding = '2px 4px';
            marcador.style.margin = '2px';
            marcador.style.fontSize = '10px';
            marcador.style.borderRadius = '2px';
            marcador.style.fontWeight = 'bold';
            marcador.style.zIndex = '9999';
            marcador.style.position = 'relative';
            marcador.setAttribute('aria-hidden', 'true');

            if (esBr) {
                elemento.after(marcador);
            } else {
                elemento.appendChild(marcador);
            }

            marcador.scrollIntoView({ behavior: "smooth", block: "center" });

            setTimeout(() => marcador.remove(), 2500);
        } else {
            // ✅ Elementos normales: outline + scroll
            elemento.scrollIntoView({ behavior: "smooth", block: "center" });
            elemento.style.outline = "3px solid #ff7a19";
            elemento.style.transition = "outline 0.4s ease-in-out";

            setTimeout(() => {
                elemento.style.outline = "";
            }, 2500);
        }
    }
});


