const idioma = navigator.language.startsWith('es') ? 'es' : 'en';

// Traducciones accesibles globalmente
let TRADUCCIONES_ACTUALES = {};

function cargarTraduccionesYAplicar(callback) {
  fetch(`lang/${idioma}.json`)
    .then(res => res.json())
    .then(traducciones => {
      TRADUCCIONES_ACTUALES = traducciones;
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const clave = el.getAttribute('data-i18n');
        if (traducciones[clave]) {
          el.textContent = traducciones[clave];
        }
      });
      if (typeof callback === 'function') callback();
    });
}

window.addEventListener('DOMContentLoaded', () => {
  const verifyButton = document.getElementById('verify');
  const copyButton = document.getElementById('copy');
  const resaltarCheckbox = document.getElementById('resaltarCheckbox');

  const port = chrome.runtime.connect({ name: "panel" });
  port.onMessage.addListener((msg) => {
    if (msg.tipo === "limpiarPanel") {
      const contenedor = document.getElementById('errores');
      if (contenedor) contenedor.innerHTML = '';
      
    }
  });

  chrome.storage.local.get('erroresWcag', (data) => {
    if (data.erroresWcag && Array.isArray(data.erroresWcag)) {
      mostrarErroresEnPopup(data.erroresWcag);
      if (resaltarCheckbox.checked) resaltarErroresEnPagina(data.erroresWcag);
    }
  });

  document.getElementById('limpiar').addEventListener('click', () => {
    chrome.storage.local.remove('erroresWcag', () => console.log("Errores eliminados del storage"));
    document.getElementById('errores').innerHTML = '';
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, { tipo: "eliminarResaltado" });
    });
    resaltarCheckbox.checked = false;
    resaltarCheckbox.disabled = true;
  });

  verifyButton.addEventListener('click', ejecutarVerificacion);
  verifyButton.addEventListener('keydown', e => { if (['Enter', ' '].includes(e.key)) { e.preventDefault(); ejecutarVerificacion(); } });
  copyButton.addEventListener('click', copiarErrores);
  copyButton.addEventListener('keydown', e => { if (['Enter', ' '].includes(e.key)) { e.preventDefault(); copiarErrores(); } });

  resaltarCheckbox.addEventListener("change", function () {
    const elementIdsToHighlight = obtenerElementIdsParaResaltar();
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, {
        tipo: "resaltarElementosError",
        elementIds: elementIdsToHighlight,
        activar: this.checked
      });
    });
  });

  function obtenerElementIdsParaResaltar() {
    const singles = Array.from(document.querySelectorAll('#errores li[data-wcag-error-id]'))
      .map(item => item.dataset.wcagErrorId);
    const multiples = Array.from(document.querySelectorAll('#errores li[data-wcag-error-ids]'))
      .flatMap(item => JSON.parse(item.dataset.wcagErrorIds));
    return singles.concat(multiples);
  }

  cargarTraduccionesYAplicar();
});

function ejecutarVerificacion() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      function: verificarAccesibilidad,
      args: [TRADUCCIONES_ACTUALES]
    }, (results) => {
      if (chrome.runtime.lastError) return console.error(chrome.runtime.lastError);
      const errores = results?.[0]?.result || [];
      mostrarErroresEnPopup(errores);
      chrome.storage.local.set({ erroresWcag: errores }, () => console.log("Errores guardados"));

      // 🔽 Si la casilla está marcada, aplicar el resaltado inmediatamente
      const checkbox = document.getElementById('resaltarCheckbox');
      if (checkbox && checkbox.checked) {
        const elementIdsToHighlight = obtenerElementIdsParaResaltar();
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          chrome.tabs.sendMessage(tabs[0].id, {
            tipo: "resaltarElementosError",
            elementIds: elementIdsToHighlight,
            activar: true
          });
        });
      }
    });
  });

  mostrarEncabezadoResultados();

  // 🔽 Habilitar la casilla después de presionar "Detectar errores"
  const checkbox = document.getElementById('resaltarCheckbox');
  if (checkbox) checkbox.disabled = false;
}

function mostrarEncabezadoResultados() {
  let encabezado = document.getElementById('results');
  encabezado.style.display = 'block';
  encabezado.setAttribute('role', 'status');
  encabezado.setAttribute('aria-live', 'polite');
  encabezado.setAttribute('data-i18n', 'results');
  setTimeout(() => { encabezado.textContent = TRADUCCIONES_ACTUALES["results"] || "RESULTADOS"; }, 50);
}

function copiarErrores() {
  const listaErrores = document.querySelectorAll('#errores li');
  if (!listaErrores.length) return alert("No hay errores para copiar.");
  let texto = Array.from(listaErrores).map(li => li.textContent).join('\n');
  navigator.clipboard.writeText(texto).then(() => alert("Errores copiados al portapapeles."));
}

function mostrarErroresEnPopup(errores) {
    let contenedorErrores = document.getElementById('errores');
    contenedorErrores.innerHTML = '';

    if (errores.length > 0) {
        errores.forEach(error => {
            // 'error' aquí es el objeto { titulo, errores, elementIds }
            // que viene de 'erroresDetectados'

            // Verifica que 'error.errores' sea un array y no esté vacío
            if (error.errores && Array.isArray(error.errores) && error.errores.length > 0) {
                const bloque = document.createElement('details'); // Este es 'bloque'
                bloque.open = false; // Asegura que se cargue cerrado

                // --- Lógica para el elemento <summary> (el título colapsable) ---
                const resumen = document.createElement('summary');
                // El primer elemento de error.errores es el mensaje de resumen (ej. "Se encontraron X párrafos...")
                const mensajeResumenDelError = error.errores[0]; 
                resumen.textContent = mensajeResumenDelError;
                resumen.classList.add('number__message'); // Tu clase para estilizar
                bloque.appendChild(resumen);

                // --- Lógica para el contenido detallado (la lista de errores individuales) ---
                const lista = document.createElement('ul');
                lista.classList.add('error-details-list'); // Añadir una clase para estilizar la lista

                // OBTENER LOS MENSAJES DE ERROR INDIVIDUALES:
                // Usamos slice(1) para obtener todos los elementos excepto el primero (el resumen).
                // Esta es la variable que debes usar en el siguiente forEach.
                const erroresIndividualesParaListar = error.errores.slice(1);

                // Iterar sobre los errores INDIVIDUALES para crear los <li>
                erroresIndividualesParaListar.forEach((errorMsg, index) => { // ¡CAMBIO AQUÍ! Usamos erroresIndividualesParaListar
                    let li = document.createElement('li');

                    const icon = document.createElement('i');
                    icon.classList.add('fas', 'fa-search'); // Asumiendo que tienes Font Awesome
                    icon.style.marginRight = '8px';

                    const textNode = document.createTextNode(errorMsg);
                    li.appendChild(icon);
                    li.appendChild(textNode);
                    li.classList.add('error'); // Clase para el estilo de cada li de error
                    li.classList.add('pointer'); // Añadido para el cursor de mano
                    li.tabIndex = 0;

                    // Obtener el ID del elemento original asociado a este error
                    // El 'index' aquí se corresponde con el índice en 'elementIds' porque 'erroresIndividualesParaListar'
                    // se "alinea" con 'elementIds' al quitar el resumen.
                    const errorId = error.elementIds && error.elementIds[index]; 
                    if (errorId) {
                        li.dataset.wcagErrorId = errorId;

                        // Lógica para determinar el 'tag' del error
                        const tag = error.tipos && error.tipos[index]
  ? error.tipos[index]
  : (
      errorMsg.includes('visible adicional') ? 'hh' :
      errorMsg.includes('<p>') ? 'p' :
      errorMsg.includes('<div') ? 'div' :
      errorMsg.includes('<span') ? 'span' :
      errorMsg.includes('<b>') ? 'b' :
      errorMsg.includes('<i>') ? 'i' :
      errorMsg.includes('<s>') ? 's' :
      errorMsg.includes('<u>') ? 'u' :
      errorMsg.includes('<ul>') || errorMsg.includes('<ol>') || errorMsg.includes('<ol> o <ul>') ? 'ul' :
      errorMsg.match(/<h[1-6]>/) ? 'h' :
      errorMsg.includes('<br') ? 'br' :
      errorMsg.includes('<small>') ? 'small' :
      errorMsg.includes('<font>') ? 'font' :
      errorMsg.includes('<th>') ? 'th' : ''
    );

                        if (tag) {
                            li.dataset.tipoError = tag;
                        }

                        // Event listener para navegar al elemento con ratón
                        li.addEventListener('click', () => {
                            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                                chrome.tabs.sendMessage(tabs[0].id, {
                                    tipo: "navegarAlElemento",
                                    errorId: errorId
                                });
                            });
                        });
                        
                        // Event listener para navegar al elemento con teclado
                        li.addEventListener('keydown', (e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                              chrome.tabs.sendMessage(tabs[0].id, {
                                tipo: "navegarAlElemento",
                                errorId: errorId
                              });
                            });
                          }
                        });

                    }

                    lista.appendChild(li);
                });

                bloque.appendChild(lista); // Añade la lista completa al <details>
                contenedorErrores.appendChild(bloque); // Añade el <details> al contenedor principal
            }
        });
    } else {
        contenedorErrores.innerHTML = '<li data-i18n="exito_no_errores" class="mensaje-exito" style="list-style-type: none;">✅Éxito: No se encontraron errores. / ✅Success: No errors found.</li>';
    }
}

function verificarAccesibilidad(traducciones) {
  const erroresDetectados = [];

        function buscarDivsSinEtiquetaInterior() {
        const divs = Array.from(document.getElementsByTagName('div'));
        const divsConError = [];
        const erroresIds = [];

        const rolesPermitidos = [
            'button', 'link', 'checkbox', 'radio', 'switch', 'tab', 'menuitem',
            'menuitemcheckbox', 'menuitemradio', 'option', 'treeitem', 'gridcell',
            'columnheader', 'rowheader', 'slider', 'spinbutton', 'listbox',
            'radiogroup', 'toolbar', 'menubar', 'menu', 'tablist', 'tree', 'grid',
            'table', 'row', 'group', 'tooltip', 'dialog', 'alertdialog',
            'article', 'note', 'region', 'rowgroup', 'cell'
        ];

        divs.forEach((div, index) => {
            let tieneTextoDirecto = false;

            for (const node of div.childNodes) {
            if (node.nodeType === Node.TEXT_NODE && node.textContent.trim().length > 0) {
                tieneTextoDirecto = true;
                break;
            }
            }

            const divRole = div.getAttribute('role');
            const tieneRolPermitido = divRole && rolesPermitidos.includes(divRole.toLowerCase());
            const dentroPermitido = div.closest('button, h1, h2, h3, h4, h5, h6, p');

            if (tieneTextoDirecto && !tieneRolPermitido && !dentroPermitido) {
            const id = Math.random().toString(36).substring(7);
            div.dataset.wcagErrorId = id;
            const mensaje = traducciones["error_div_no_permitido_individual"] || "Error: div con contenido directo no permitido";
            divsConError.push(`${mensaje} #${index + 1}`);
            erroresIds.push(id);
            }
        });

        if (divsConError.length > 0) {
            const plantillaResumen = traducciones["divs_no_permitidos_resumen"];
            const resumen = plantillaResumen
            ? plantillaResumen.replace('{cantidad}', divsConError.length)
            : `Se encontraron ${divsConError.length} elementos <div> con texto directo no permitido.`;

            erroresDetectados.push({
            titulo: "Divs con contenido directo no permitido",
            errores: [resumen, ...divsConError],
            elementIds: erroresIds
            });
        }
        }

        function buscarSpansSinCondicion() {
            const spans = Array.from(document.getElementsByTagName('span'));
            const spansConError = [];
            const erroresIds = [];

            const rolesPermitidosSpan = [
                'button', 'link', 'checkbox', 'radio', 'switch', 'tab', 'menuitem',
                'menuitemcheckbox', 'menuitemradio', 'option', 'treeitem', 'slider',
                'spinbutton', 'listbox', 'radiogroup', 'toolbar', 'menubar', 'menu',
                'tablist', 'tree', 'tooltip', 'status', 'alert', 'log', 'marquee',
                'timer', 'term', 'definition', 'caption', 'figurecaption', 'label',
                'legend', 'strong', 'emphasis', 'code', 'suggestion', 'insertion',
                'deletion', 'note', 'cell', 'columnheader', 'rowheader', 'heading'
            ];

            const etiquetasFormatoPermitidas = ['b', 'i', 'em', 'strong', 'mark', 'small', 'del', 'ins', 'sub', 'sup'];
            const etiquetasSemanticasPermitidas = ['p', 'a', 'button', 'ul', 'li', 'th', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'input', 'label', 'summary', 'code', 'legend'];

            spans.forEach((span) => {
                const padrePermitido = etiquetasSemanticasPermitidas.includes(span.parentElement?.tagName?.toLowerCase());
                const contenidoHTML = span.innerHTML.trim();
                const interiorComienzaConTexto = contenidoHTML !== '' && contenidoHTML[0] !== '<';
                const estaDentroDeElementoPermitido = span.closest(etiquetasSemanticasPermitidas.join(', '));

                const spanRole = span.getAttribute('role');
                const tieneRolDirectoPermitido = spanRole && rolesPermitidosSpan.includes(spanRole.toLowerCase());

                // Verificación de ancestros con role permitido
                const ancestroConRol = span.closest('[role]');
                let tieneAncestroConRolPermitido = false;
                if (ancestroConRol) {
                    const rol = ancestroConRol.getAttribute('role')?.toLowerCase();
                    tieneAncestroConRolPermitido = rolesPermitidosSpan.includes(rol);
                }

                // Verificación: formato dentro de semántica
                let esSpanDentroDeFormatoPermitidoYSemantico = false;
                let currentParent = span.parentElement;
                let foundFormattingTag = false;

                while (currentParent) {
                    const tagName = currentParent.tagName?.toLowerCase();
                    if (etiquetasFormatoPermitidas.includes(tagName)) {
                        foundFormattingTag = true;
                    } else if (foundFormattingTag && etiquetasSemanticasPermitidas.includes(tagName)) {
                        esSpanDentroDeFormatoPermitidoYSemantico = true;
                        break;
                    } else if (tagName && !etiquetasFormatoPermitidas.includes(tagName) && !etiquetasSemanticasPermitidas.includes(tagName)) {
                        break;
                    }
                    currentParent = currentParent.parentElement;
                }

                if (!padrePermitido && interiorComienzaConTexto && !estaDentroDeElementoPermitido && !tieneRolDirectoPermitido && !esSpanDentroDeFormatoPermitidoYSemantico && !tieneAncestroConRolPermitido) {
                    const errorId = Math.random().toString(36).substring(7);
                    span.dataset.wcagErrorId = errorId;
                    spansConError.push(traducciones["error_span_no_permitido_individual"] || "Error: span con contenido directo no permitido");
                    erroresIds.push(errorId);
                }
            });

            if (spansConError.length > 0) {
                const cantidad = spansConError.length;
                const resumen = traducciones["spans_no_permitidos_resumen"]
                    ? traducciones["spans_no_permitidos_resumen"].replace('{cantidad}', cantidad)
                    : `Se encontraron ${cantidad} elementos <span> con contenido directo no permitido.`;

                erroresDetectados.push({
                    titulo: "Spans con contenido directo no permitido",
                    errores: [resumen, ...spansConError],
                    elementIds: erroresIds
                });
            }
        }

        function buscarEtiquetasP() {
        const elementos = document.querySelectorAll('p');
        const vacios = [];
        const ids = [];

        elementos.forEach(p => {
            const html = p.innerHTML.trim();
            if (!html || /^(\s*&nbsp;)+\s*$/i.test(html)) {
            const id = Math.random().toString(36).substring(7);
            p.dataset.wcagErrorId = id;
            vacios.push(traducciones["error_parrafo_vacio_individual"] || "Error: Etiqueta <p> vacía o con &nbsp;");
            ids.push(id);
            }
        });

        if (vacios.length) {
            const plantillaResumen = traducciones["parrafos_vacios_resumen"];
            const resumen = plantillaResumen
            ? plantillaResumen.replace('{cantidad}', vacios.length)
            : `Se encontraron ${vacios.length} párrafos vacíos en la página.`;

            erroresDetectados.push({
            titulo: "p vacíos",
            errores: [resumen, ...vacios],
            elementIds: ids
            });
        }
        }

        function contarEtiquetas() {
        const etiquetasProhibidas = ['b', 'u', 'br', 'font', 's', 'small', 'i'];

        etiquetasProhibidas.forEach(etiqueta => {
            const elementos = Array.from(document.querySelectorAll(etiqueta)).filter(el =>
            el.getAttribute('role') !== 'presentation' &&
            el.getAttribute('aria-hidden') !== 'true'
            );

            const cantidad = elementos.length;
            if (cantidad > 0) {
            const erroresIndividuales = [];
            const elementIdsIndividuales = [];

            elementos.forEach(el => {
                const id = Math.random().toString(36).substring(7);
                el.dataset.wcagErrorId = id;
                const claveError = `error_${etiqueta}_individual`;
                const mensaje = traducciones[claveError] || `Error: Se encontró una etiqueta <${etiqueta}>`;
                erroresIndividuales.push(mensaje);
                elementIdsIndividuales.push(id);
            });

            const claveResumen = `${etiqueta}_resumen`;
            const resumen = traducciones[claveResumen]
                ? traducciones[claveResumen].replace('{cantidad}', cantidad)
                : `Se encontraron ${cantidad} etiquetas <${etiqueta}> en la página.`;

            erroresDetectados.push({
                titulo: `Etiquetas <${etiqueta}>`,
                errores: [resumen, ...erroresIndividuales],
                elementIds: elementIdsIndividuales
            });
            }
        });
        }

        function verificarEncabezadosVacios() {
        const niveles = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
        const errores = [];
        const ids = [];
        const tipos = [];

        niveles.forEach(nivel => {
            const elementos = document.querySelectorAll(nivel);
            elementos.forEach(h => {
            const texto = h.innerText.trim();
            const oculto = window.getComputedStyle(h).display === 'none';
            const tieneImgAlt = !!h.querySelector('img[alt]');
            const tieneSpan = h.querySelector('span') !== null;
            const estaCerrado = h.closest('details:not([open])');

            if (!oculto && !tieneImgAlt && !tieneSpan && texto === '' && !estaCerrado) {
                const id = Math.random().toString(36).substring(7);
                h.dataset.wcagErrorId = id;
                errores.push(traducciones["error_encabezado_vacio_individual"] || `Error: Encabezado vacío`);
                ids.push(id);
                tipos.push('h');
            }
            });
        });

        if (errores.length > 0) {
            const cantidad = errores.length;
            const resumen = traducciones["encabezados_vacios_resumen"]
            ? traducciones["encabezados_vacios_resumen"].replace('{cantidad}', cantidad)
            : `Se encontraron ${cantidad} encabezados vacíos en la página.`;

            erroresDetectados.push({
            titulo: "Encabezados vacíos",
            errores: [resumen, ...errores],
            elementIds: ids,
            tipos: tipos
            });
        }
        }

        function verificarH1Unico() {
          let h1s = Array.from(document.getElementsByTagName('h1'));

          let h1sVisibles = h1s.filter(h1 => {
            let el = h1;
            while (el) {
              const style = window.getComputedStyle(el);
              const rect = el.getBoundingClientRect();

              if (
                style.display === 'none' ||
                rect.width === 0 ||
                rect.height === 0
              ) {
                return false;
              }

              el = el.parentElement;
            }
            return true;
          });

          const cantidad = h1sVisibles.length;

          if (cantidad > 1) {
            const h1Errores = [];
            const h1Ids = [];
            const h1Tipos = [];

            h1sVisibles.forEach((h1) => {
              const errorId = Math.random().toString(36).substring(7);
              h1.dataset.wcagErrorId = errorId;
              h1Errores.push(
                traducciones["error_encabezado_repetido_individual"] ||
                "Error: Se encontró una etiqueta <h1> visible adicional"
              );
              h1Ids.push(errorId);
              h1Tipos.push('hh');
            });

            const resumen = traducciones["encabezados_repetidos_resumen"]
              ? traducciones["encabezados_repetidos_resumen"].replace('{cantidad}', cantidad)
              : `Se encontraron ${cantidad} etiquetas <h1> visibles. Solo debe haber una.`;

            erroresDetectados.push({
              titulo: "<h1> duplicado",
              errores: [resumen, ...h1Errores],
              elementIds: h1Ids,
              tipos: h1Tipos
            });
          }
        }

        function listarListasVacias() {
            const listas = document.querySelectorAll('ul, ol');
            const errores = [];
            const ids = [];
            const tipos = [];

            listas.forEach(lista => {
                if (lista.children.length === 0) {
                    let el = lista;
                    let visible = true;
                    while (el) {
                        const estilo = window.getComputedStyle(el);
                        const rect = el.getBoundingClientRect();

                        if (
                            estilo.display === 'none' ||
                            rect.width === 0 ||
                            rect.height === 0
                        ) {
                            visible = false;
                            break;
                        }

                        el = el.parentElement;
                    }

                    if (visible) {
                        const id = Math.random().toString(36).substring(7);
                        lista.dataset.wcagErrorId = id;
                        errores.push(traducciones["error_lista_vacia_individual"] || "Error: Lista vacía (<ul> o <ol>)");
                        ids.push(id);
                        tipos.push('ul');
                    }
                }
            });

            if (errores.length > 0) {
                const resumen = traducciones["listas_vacias_resumen"]
                    ? traducciones["listas_vacias_resumen"].replace('{cantidad}', errores.length)
                    : `Se encontraron ${errores.length} listas <ul> o <ol> vacías.`;

                erroresDetectados.push({
                    titulo: "Listas vacías",
                    errores: [resumen, ...errores],
                    elementIds: ids,
                    tipos: tipos
                });
            }
        }

        function verificarEncabezadosTablaVacios() {
          const ths = document.querySelectorAll('th');
          const errores = [];
          const ids = [];

          ths.forEach((th, index) => {
            const estilo = window.getComputedStyle(th);
            const oculto = estilo.display === 'none' || th.getAttribute('aria-hidden') === 'true';

            if (!oculto && th.innerText.trim() === '') {
              const id = Math.random().toString(36).substring(7);
              th.dataset.wcagErrorId = id;
              errores.push(traducciones["error_th_individual"] || `Error: Celda <th> vacía en la posición ${index + 1}`);
              ids.push(id);
            }
          });

          if (errores.length > 0) {
            const resumen = traducciones["th_resumen"]
              ? traducciones["th_resumen"].replace('{cantidad}', errores.length)
              : `Se encontraron ${errores.length} celdas <th> vacías en tablas.`;

            erroresDetectados.push({
              titulo: "Encabezados de tabla vacíos",
              errores: [resumen, ...errores],
              elementIds: ids
            });
          }
        }

          buscarDivsSinEtiquetaInterior();
          buscarSpansSinCondicion();
          buscarEtiquetasP();
          contarEtiquetas();
          verificarEncabezadosVacios();
          verificarH1Unico();
          listarListasVacias();
          verificarEncabezadosTablaVacios();

          return erroresDetectados;
        }


// Función para limpiar los mensajes de error y la casilla de verificación
console.log('Panel JS cargado');

chrome.runtime.onMessage.addListener((msg) => {
  console.log('onMessage recibido en panel:', msg);
  if (msg.tipo === 'limpiarPanel') {
    limpiar();
  }
});

const port = chrome.runtime.connect({ name: 'panel' });
port.onMessage.addListener((msg) => {
  console.log('port.onMessage recibido en panel:', msg);
  if (msg.tipo === 'limpiarPanel') {
    limpiar();
  }
});

function limpiar() {
  console.log('Ejecutando limpiar en panel');
  const contenedor = document.getElementById('errores');
  if (contenedor) contenedor.innerHTML = '';

  const checkbox = document.getElementById('resaltarCheckbox');
  if (checkbox) {
    checkbox.checked = false;
    checkbox.disabled = true;
    console.log('Checkbox limpiado y deshabilitado');
  } else {
    console.log('Checkbox no encontrado');
  }
}
