chrome.runtime.onMessage.addListener(function (message, _sender, _sendResponse) {
    console.log("Mensaje recibido en content:", message);

    if (message.tipo === "resaltarElementosError" && Array.isArray(message.elementIds)) {
        message.elementIds.forEach(errorId => {
            const elements = document.querySelectorAll(`[data-wcag-error-id="${errorId}"]`);
            elements.forEach(element => {
                if (message.activar) {
                    element.classList.add('resaltado-error');

                    const tag = element.tagName.toLowerCase();

                    if (tag === 'div') {
                        element.classList.add('error-div');
                    } else if (tag === 'span') {
                        element.classList.add('error-span');
                    } else if (tag === 'b') {
                        element.classList.add('error-b');
                    } else if (tag === 'i') {
                        element.classList.add('error-i');
                    } else if (tag === 's') {
                        element.classList.add('error-s');
                    } else if (tag === 'u') {
                        element.classList.add('error-u');
                    } else if (tag === 'font') {
                        element.classList.add('error-font');
                    } else if (tag === 'h1') {
                        element.classList.add('error-hh');
                    } else if (/^h[1-6]$/.test(tag)) {
                        element.classList.add('error-h');
                    } else if (tag === 'p') {
                        if (element.textContent.trim() === '') {
                            element.classList.add('error-p');
                        }
                    } else if (tag === 'ul' || tag === 'ol') {
                        if (element.children.length === 0 && element.textContent.trim() === '') {
                            element.classList.add('error-lista');
                        }
                    } else if (tag === 'br') {
                        element.classList.add('error-br');
                    } else if (tag === 'small') {
                        element.classList.add('error-small');
                    } else if (tag === 'th') {
                        element.classList.add('error-th');
                    }
                } else {
                    element.classList.remove('resaltado-error');
                    element.classList.remove('error-div');
                    element.classList.remove('error-span');
                    element.classList.remove('error-b');
                    element.classList.remove('error-i');
                    element.classList.remove('error-s');
                    element.classList.remove('error-u');
                    element.classList.remove('error-font');
                    element.classList.remove('error-hh');
                    element.classList.remove('error-h');
                    element.classList.remove('error-p');
                    element.classList.remove('error-lista');
                    element.classList.remove('error-br');
                    element.classList.remove('error-small');
                    element.classList.remove('error-th');
                }
            });
        });
    }

    // ✅ Limpiar todo con animación
    if (message.tipo === "eliminarResaltado") {
        const clases = [
            'resaltado-error',
            'error-div',
            'error-span',
            'error-b',
            'error-i',
            'error-s',
            'error-u',
            'error-font',
            'error-hh',
            'error-h',
            'error-p',
            'error-lista',
            'error-br',
            'error-small',
            'error-th'
        ];

        clases.forEach(clase => {
            document.querySelectorAll(`.${clase}`).forEach(el => {
                el.style.transition = 'outline 0.3s ease, background-color 0.3s ease';
                el.style.outline = 'none';
                el.style.backgroundColor = 'transparent';

                setTimeout(() => {
                    el.classList.remove(clase);
                }, 300);
            });
        });
    }
});

