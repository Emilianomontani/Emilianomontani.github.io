chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    // Lógica para resaltar y aplicar clases CSS
    if (message.tipo === "resaltarElementosError" && Array.isArray(message.elementIds)) {
        message.elementIds.forEach(errorId => {
            const elements = document.querySelectorAll(`[data-wcag-error-id="${errorId}"]`);
            elements.forEach(element => {
                if (message.activar) {
                    element.classList.add('resaltado-error');

                    const tag = element.tagName.toLowerCase();

                    if (tag === 'div') {
                        element.classList.add('error-div');
                    } else if (tag === 'span') {
                        element.classList.add('error-span');
                    } else if (tag === 'b') {
                        element.classList.add('error-b');
                    } else if (tag === 'i') {
                        element.classList.add('error-i');
                    } else if (tag === 's') {
                        element.classList.add('error-s');
                    } else if (tag === 'u') {
                        element.classList.add('error-u');
                    } else if (tag === 'font') {
                        element.classList.add('error-font');
                    } else if (tag === 'h1') {
                        element.classList.add('error-hh');
                    } else if (/^h[1-6]$/.test(tag)) {
                        element.classList.add('error-h');
                    } else if (tag === 'p') {
                        element.classList.add('error-p');
                    } else if (tag === 'ul' || tag === 'ol' || tag === 'li') {
                        element.classList.add('error-lista');
                    } else if (tag === 'br') {
                        element.classList.add('error-br');
                    } else if (tag === 'small') {
                        element.classList.add('error-small');
                    } else if (tag === 'th') {
                        element.classList.add('error-th');
                    }
                } else {
                    element.classList.remove('resaltado-error');
                    element.classList.remove('error-div');
                    element.classList.remove('error-span');
                    element.classList.remove('error-b');
                    element.classList.remove('error-i');
                    element.classList.remove('error-s');
                    element.classList.remove('error-u');
                    element.classList.remove('error-font');
                    element.classList.remove('error-hh');
                    element.classList.remove('error-h');
                    element.classList.remove('error-p');
                    element.classList.remove('error-lista');
                    element.classList.remove('error-br');
                    element.classList.remove('error-small');
                    element.classList.remove('error-th');
                }
            });
        });
    }

    // Lógica para navegar y hacer scroll al elemento
    if (message.tipo === "navegarAlElemento" && message.errorId) {
        const selector = `[data-wcag-error-id="${message.errorId}"]`;
        const elemento = document.querySelector(selector);

        if (!elemento) {
            alert("Elemento no encontrado. ¿Quizás fue eliminado o está fuera del DOM?");
            return;
        }

        const estilo = window.getComputedStyle(elemento);
        const visible = estilo.display !== "none" && estilo.visibility !== "hidden";

        if (!visible) {
            alert("El elemento existe pero está oculto (por display:none o visibility:hidden).");
            return;
        }

        const tag = elemento.tagName.toLowerCase();
        const esEncabezado = /^h[1-6]$/.test(tag);
        const esLista = tag === 'ul' || tag === 'ol';
        const esParrafo = tag === 'p';
        const esBr = tag === 'br';

        const estaVacio = elemento.innerText.trim() === '' && elemento.children.length === 0;

        if (esBr || (estaVacio && (esParrafo || esEncabezado || esLista))) {
            const marcador = document.createElement('span');
            marcador.textContent = '⬅︎';
            marcador.style.background = '#ff7a19';
            marcador.style.color = '#fff';
            marcador.style.padding = '2px 4px';
            marcador.style.margin = '2px';
            marcador.style.fontSize = '10px';
            marcador.style.borderRadius = '2px';
            marcador.style.fontWeight = 'bold';
            marcador.style.zIndex = '9999';
            marcador.style.position = 'relative';
            marcador.setAttribute('aria-hidden', 'true');

            if (esBr) {
                elemento.after(marcador);
            } else {
                elemento.appendChild(marcador);
            }

            marcador.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

            setTimeout(() => marcador.remove(), 2500);
        } else {
            elemento.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });
            elemento.style.outline = "3px solid #ff7a19";
            elemento.style.transition = "outline 0.4s ease-in-out";

            setTimeout(() => {
                elemento.style.outline = "none";
            }, 2000);
        }
    }

    // Lógica para eliminar todo el resaltado de la página
    if (message.tipo === "eliminarResaltado") {
        const clases = [
            'resaltado-error',
            'error-div',
            'error-span',
            'error-b',
            'error-i',
            'error-s',
            'error-u',
            'error-font',
            'error-hh',
            'error-h',
            'error-p',
            'error-lista',
            'error-br',
            'error-small',
            'error-th'
        ];

        clases.forEach(clase => {
            document.querySelectorAll(`.${clase}`).forEach(el => {
                el.style.transition = 'outline 0.3s ease, background-color 0.3s ease';
                el.style.outline = 'none';
                el.style.backgroundColor = 'transparent';

                setTimeout(() => {
                    el.classList.remove(clase);
                }, 300);
            });
        });
    }
});