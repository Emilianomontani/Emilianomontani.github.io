// background.js (modificado)
// Puedes tener otras lógicas aquí si las necesitas, pero elimina la inyección de content.js al hacer clic en el icono.

console.log("Background script activo.");
