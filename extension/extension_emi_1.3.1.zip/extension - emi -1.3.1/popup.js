document.addEventListener('DOMContentLoaded', function () {
    const verifyButton = document.getElementById('verify');
    const copyButton = document.getElementById('copy');
    const resaltarCheckbox = document.getElementById('resaltarCheckbox');

    verifyButton.addEventListener('click', ejecutarVerificacion);
    verifyButton.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            ejecutarVerificacion();
        }
    });

    copyButton.addEventListener('click', copiarErrores);
    copyButton.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            copiarErrores();
        }
    });

    resaltarCheckbox.addEventListener("change", function () {
        const activo = this.checked;
        const elementIdsToHighlight = obtenerElementIdsParaResaltar();
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                tipo: "resaltarElementosError",
                elementIds: elementIdsToHighlight,
                activar: activo
            });
        });
    });

    function obtenerElementIdsParaResaltar() {
        const listItems = document.querySelectorAll('#errores li[data-wcag-error-id]');
        const singleIds = Array.from(listItems).map(item => item.dataset.wcagErrorId);

        const listItemsMultiple = document.querySelectorAll('#errores li[data-wcag-error-ids]');
        const multipleIds = Array.from(listItemsMultiple).reduce((acc, item) => {
            const ids = JSON.parse(item.dataset.wcagErrorIds);
            return acc.concat(ids);
        }, []);

        return singleIds.concat(multipleIds);
    }

    function ejecutarVerificacion() {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                function: verificarAccesibilidad
            }, (results) => {
                if (chrome.runtime.lastError) {
                    console.error(chrome.runtime.lastError);
                    return;
                }
                if (results && results[0] && results[0].result) {
                    mostrarErroresEnPopup(results[0].result);
                }
            });
        });
        mostrarEncabezadoResultados();
    }

    function mostrarEncabezadoResultados() {
        let encabezado = document.getElementById('results');
        encabezado.style.display = 'block';
        encabezado.setAttribute('role', 'status');
        encabezado.setAttribute('aria-live', 'polite');
        setTimeout(() => {
            encabezado.textContent = "Resultados actualizados:";
        }, 50);
    }

    function copiarErrores() {
        const listaErrores = document.querySelectorAll('#errores li');
        const encabezados = document.querySelectorAll('#errores h3');
        if (listaErrores.length === 0) {
            alert("No hay errores para copiar.");
            return;
        }
        let texto = "";
        encabezados.forEach(h3 => {
            texto += h3.textContent + "\n";
        });
        listaErrores.forEach(li => {
            texto += li.textContent + "\n";
        });
        navigator.clipboard.writeText(texto).then(() => {
            alert("Errores copiados al portapapeles.");
        }).catch(err => {
            console.error("Error al copiar:", err);
        });
    }
});

function verificarAccesibilidad() {
    let erroresDetectados = [];

    function buscarEtiquetasP() {
        let parrafos = document.querySelectorAll('p');
        const parrafosVaciosEncontrados = [];
        const elementIdsParrafosVacios = [];
    
        parrafos.forEach(parrafo => {
            if (parrafo.innerHTML.trim() === '' || parrafo.innerHTML.trim() === '&nbsp;') {
                const errorId = Math.random().toString(36).substring(7);
                parrafo.dataset.wcagErrorId = errorId;
                parrafosVaciosEncontrados.push(`❌ Error: Etiqueta <p> vacía o con &nbsp;`);
                elementIdsParrafosVacios.push(errorId);
            }
        });
    
        if (parrafosVaciosEncontrados.length > 0) {
            erroresDetectados.push({
                titulo: "Parrafos vacíos o con &nbsp;",
                errores: [`Se encontraron ${parrafosVaciosEncontrados.length} párrafos vacíos o con &nbsp; en la página.`].concat(parrafosVaciosEncontrados.map((error, index) => `${error} #${index + 1}`)),
                elementIds: elementIdsParrafosVacios
            });
        }
    }

    function contarEtiquetas() {
        let etiquetasProhibidas = ['b', 'u', 'br', 'font'];
        etiquetasProhibidas.forEach(etiqueta => {
            let elementos = Array.from(document.querySelectorAll(etiqueta))
                .filter(elemento =>
                    elemento.getAttribute('role') !== 'presentation' &&
                    elemento.getAttribute('aria-hidden') !== 'true'
                );
    
            const cantidad = elementos.length;
            if (cantidad > 0) {
                const erroresIndividuales = [];
                const elementIdsIndividuales = [];
                elementos.forEach(elemento => {
                    const errorId = Math.random().toString(36).substring(7);
                    elemento.dataset.wcagErrorId = errorId;
                    erroresIndividuales.push(`❌ Error: Etiqueta <${etiqueta}> encontrada.`);
                    elementIdsIndividuales.push(errorId);
                });
                erroresDetectados.push({
                    titulo: `Etiquetas <${etiqueta}> encontradas`,
                    errores: [`Se encontraron ${cantidad} etiquetas <${etiqueta}> en la página.`].concat(erroresIndividuales),
                    elementIds: elementIdsIndividuales
                });
            }
        });
    }

    function evaluarEtiquetaSmall() {
        let elementosSmall = Array.from(document.querySelectorAll('small'));
        const erroresIndividuales = [];
        const elementIdsIndividuales = [];
    
        elementosSmall.forEach(elemento => {
            // Verificar si está dentro de etiquetas semánticas permitidas
            const padresPermitidos = ['label', 'figcaption', 'cite', 'p', 'li','th','td'];
            let esPermitido = padresPermitidos.some(padre => elemento.closest(padre));
    
            // Verificar si tiene atributos de accesibilidad válidos
            const rolesPermitidos = ['presentation', 'status', 'note', 'tooltip', 'alert', 'caption', 'contentinfo'];
            const tieneRolePermitido = rolesPermitidos.includes(elemento.getAttribute('role'));
            const tieneAriaHidden = elemento.getAttribute('aria-hidden') === 'true';
            const tieneDisplayNone = getComputedStyle(elemento).display === 'none';
    
            if (!esPermitido && !tieneRolePermitido && !tieneAriaHidden && !tieneDisplayNone) {
                const errorId = Math.random().toString(36).substring(7);
                elemento.dataset.wcagErrorId = errorId;
                erroresIndividuales.push(`❌ Error: Etiqueta <small> usada incorrectamente.`);
                elementIdsIndividuales.push(errorId);
            }
        });
    
        if (erroresIndividuales.length > 0) {
            erroresDetectados.push({
                titulo: `Etiquetas <small> usadas incorrectamente`,
                errores: [`Se encontraron ${erroresIndividuales.length} etiquetas <small> usadas incorrectamente en la página.`].concat(erroresIndividuales),
                elementIds: elementIdsIndividuales
            });
        }
    }

    function contarEtiquetasI() {
        let etiquetasI = document.getElementsByTagName('i');
        const cantidadTotal = etiquetasI.length;
        if (cantidadTotal > 0) {
            const erroresI = [];
            const elementIdsI = [];
            let contadorConAtributo = 0;
    
            for (let i = 0; i < cantidadTotal; i++) {
                const iElement = etiquetasI[i];
                const errorId = Math.random().toString(36).substring(7);
                iElement.dataset.wcagErrorId = errorId;
                erroresI.push(`❌ Error: Se encontró una etiqueta <i>.`);
                elementIdsI.push(errorId);
                if (iElement.hasAttribute('aria-hidden') && iElement.getAttribute('aria-hidden').toLowerCase() === 'true') {
                    contadorConAtributo++;
                }
            }
    
            erroresDetectados.push({
                titulo: "Etiquetas <i> encontradas",
                errores: [`Se encontraron ${cantidadTotal} etiquetas <i> en la página.`].concat(erroresI),
                resumen: `Atención: ${contadorConAtributo} de ${cantidadTotal} etiquetas <i> tienen aria-hidden="true".`,
                elementIds: elementIdsI
                
            });
        }
    }

    function buscarDivsSinEtiquetaInterior() {
        let divs = Array.from(document.getElementsByTagName('div'));
        const divsConError = [];
        const rolesPermitidos = [
            'button', 'link', 'checkbox', 'radio', 'switch', 'tab', 'menuitem',
            'menuitemcheckbox', 'menuitemradio', 'option', 'treeitem', 'gridcell',
            'columnheader', 'rowheader', 'slider', 'spinbutton', 'listbox',
            'radiogroup', 'toolbar', 'menubar', 'menu', 'tablist', 'tree', 'grid',
            'table', 'row', 'group', 'tooltip', 'dialog', 'alertdialog',
            'article', 'note', 'region', 'rowgroup','cell'
        ];
    
        divs.forEach((div, index) => {
            let contenidoHTML = div.innerHTML.trim();
            let estaDentroDeElementoPermitido = div.closest('a, button, h1, h2, h3, h4, h5, h6, li');
    
            // Comprobar si el div tiene un role permitido directamente
            const divRole = div.getAttribute('role');
            const tieneRolDirectoPermitido = divRole && rolesPermitidos.includes(divRole.toLowerCase());
    
            if (contenidoHTML !== '' && contenidoHTML[0] !== '<' && !estaDentroDeElementoPermitido && !tieneRolDirectoPermitido) {
                const errorId = Math.random().toString(36).substring(7);
                div.dataset.wcagErrorId = errorId;
                divsConError.push(`❌ Error: div con contenido directo no permitido #${index + 1}: ${div.outerHTML.substring(0, 100)}`);
            }
        });
    
        if (divsConError.length > 0) {
            erroresDetectados.push({
                titulo: "Divs con contenido directo no permitido",
                errores: divsConError,
                elementIds: Array.from(document.querySelectorAll('div[data-wcag-error-id]'))
                    .filter(div => {
                        let contenidoHTML = div.innerHTML.trim();
                        let estaDentroDeElementoPermitido = div.closest('a, button, h1, h2, h3, h4, h5, h6, li');
                        const divRole = div.getAttribute('role');
                        const tieneRolDirectoPermitido = divRole && rolesPermitidos.includes(divRole.toLowerCase());
                        return contenidoHTML !== '' && contenidoHTML[0] !== '<' && !estaDentroDeElementoPermitido && !tieneRolDirectoPermitido;
                    })
                    .map(div => div.dataset.wcagErrorId)
            });
        }
    }

    function buscarSpansSinCondicion() {
        let spans = Array.from(document.getElementsByTagName('span'));
        const spansConError = [];
        const rolesPermitidosSpan = [
            'button', 'link', 'checkbox', 'radio', 'switch', 'tab', 'menuitem',
            'menuitemcheckbox', 'menuitemradio', 'option', 'treeitem', 'slider',
            'spinbutton', 'listbox', 'radiogroup', 'toolbar', 'menubar', 'menu',
            'tablist', 'tree', 'tooltip', 'status', 'alert', 'log', 'marquee',
            'timer', 'term', 'definition', 'caption', 'figurecaption', 'label',
            'legend', 'strong', 'emphasis', 'code', 'suggestion', 'insertion',
            'deletion', 'note', 'cell', 'columheader'
        ];
    
        spans.forEach((span, index) => {
            let padrePermitido = ['p', 'a', 'button', 'ul', 'li', 'th', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'input', 'label','summary'].includes(span.parentElement?.tagName?.toLowerCase());
            let contenidoHTML = span.innerHTML.trim();
            let interiorComienzaConMenorQue = contenidoHTML !== '' && contenidoHTML[0] !== '<';
            let estaDentroDeElementoPermitido = span.closest('a, button, h1, h2, h3, h4, h5, h6, li, input, label');
    
            // Comprobar si el span tiene un role permitido directamente
            const spanRole = span.getAttribute('role');
            const tieneRolDirectoPermitido = spanRole && rolesPermitidosSpan.includes(spanRole.toLowerCase());
    
            if (!padrePermitido && interiorComienzaConMenorQue && !estaDentroDeElementoPermitido && !tieneRolDirectoPermitido && spanRole?.toLowerCase() !== 'heading') {
                const errorId = Math.random().toString(36).substring(7);
                span.dataset.wcagErrorId = errorId;
                spansConError.push(`❌ Error: span con contenido directo no permitido #${index + 1}: ${span.outerHTML.substring(0, 100)}`);
            }
        });
    
        if (spansConError.length > 0) {
            erroresDetectados.push({
                titulo: "Spans con contenido directo no permitido",
                errores: spansConError,
                elementIds: Array.from(document.querySelectorAll('span[data-wcag-error-id]'))
                    .filter(span => {
                        let padrePermitido = ['p', 'a', 'button', 'ul', 'li', 'th', 'tr', 'td', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'input', 'label'].includes(span.parentElement?.tagName?.toLowerCase());
                        let contenidoHTML = span.innerHTML.trim();
                        let interiorComienzaConMenorQue = contenidoHTML !== '' && contenidoHTML[0] !== '<';
                        let estaDentroDeElementoPermitido = span.closest('p, a, button, h1, h2, h3, h4, h5, h6, li, th, tr, td, input, label');
                        const spanRole = span.getAttribute('role');
                        const tieneRolDirectoPermitido = spanRole && rolesPermitidosSpan.includes(spanRole.toLowerCase());
                        return !padrePermitido && interiorComienzaConMenorQue && !estaDentroDeElementoPermitido && !tieneRolDirectoPermitido && spanRole?.toLowerCase() !== 'heading';
                    })
                    .map(span => span.dataset.wcagErrorId)
            });
        }
    }

    function listarListasVacias() {
        let listas = document.querySelectorAll('ul, ol');
        const listasVaciasEncontradas = [];
        const listasVaciasIds = [];

        listas.forEach(lista => {
            let estilo = window.getComputedStyle(lista);
            if (lista.children.length === 0 && estilo.display !== "none") {
                const errorId = Math.random().toString(36).substring(7);
                lista.dataset.wcagErrorId = errorId;
                listasVaciasEncontradas.push(`❌ Error: Se encontró una lista vacía.`);
                listasVaciasIds.push(errorId);
            }
        });

        if (listasVaciasEncontradas.length > 0) {
            erroresDetectados.push({
                titulo: "Listas vacías detectadas",
                errores: [`Se encontraron ${listasVaciasEncontradas.length} listas vacías en la página.`].concat(listasVaciasEncontradas.map((error, index) => `${error} #${index + 1}`)),
                elementIds: listasVaciasIds
            });
        }
    }

    function verificarEncabezadosVacios() {
        let encabezados = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
        const todosLosEncabezadosVaciosErrores = [];
        const todosLosEncabezadosVaciosIds = [];

        encabezados.forEach(nivel => {
            let elementos = document.querySelectorAll(nivel);
            const encabezadosVaciosDeNivelErrores = [];
            const encabezadosVaciosDeNivelIds = [];

            elementos.forEach((h, index) => {
                let contenido = h.innerText.trim();
                let tieneDisplayNone = window.getComputedStyle(h).display === 'none';
                let tieneImagenConAlt = false;
                let enlaces = h.querySelectorAll('a');
                enlaces.forEach(a => {
                    let imagen = a.querySelector('img');
                    if (imagen && imagen.alt.trim() !== '') {
                        tieneImagenConAlt = true;
                    }
                });
                let contieneSpan = h.querySelector('span') !== null;

                if (!tieneDisplayNone && !tieneImagenConAlt && !contieneSpan && contenido === '') {
                    const errorId = Math.random().toString(36).substring(7);
                    h.dataset.wcagErrorId = errorId;
                    encabezadosVaciosDeNivelErrores.push(`❌ Error: Encabezado <${nivel}> vacío.`);
                    encabezadosVaciosDeNivelIds.push(errorId);
                }
            });

            todosLosEncabezadosVaciosErrores.push(...encabezadosVaciosDeNivelErrores);
            todosLosEncabezadosVaciosIds.push(...encabezadosVaciosDeNivelIds);
        });

        if (todosLosEncabezadosVaciosErrores.length > 0) {
            erroresDetectados.push({
                titulo: "Encabezados vacíos detectados",
                errores: [`Se encontraron ${todosLosEncabezadosVaciosErrores.length} encabezados vacíos en la página.`].concat(todosLosEncabezadosVaciosErrores.map((error, index) => `${error} #${index + 1}`)),
                elementIds: todosLosEncabezadosVaciosIds
            });
        }
    }

function verificarEncabezadosTablaVacios() {
    let ths = document.querySelectorAll('th');
    const thsVaciosErrores = [];
    const thsVaciosIds = [];

    ths.forEach((th, index) => {
        const estilo = window.getComputedStyle(th);
        const estaOculto = estilo.display === 'none' || th.getAttribute('aria-hidden') === 'true';

        if (!estaOculto && th.innerText.trim() === '') {
            const errorId = Math.random().toString(36).substring(7);
            th.dataset.wcagErrorId = errorId;
            thsVaciosErrores.push(`❌ Error: Encabezado de tabla vacío en la posición ${index + 1}`);
            thsVaciosIds.push(errorId);
        }
    });

    if (thsVaciosErrores.length > 0) {
        erroresDetectados.push({
            titulo: "Encabezados de tabla vacíos",
            errores: [`Se encontraron ${thsVaciosErrores.length} encabezados de tabla vacíos en la página.`].concat(thsVaciosErrores),
            elementIds: thsVaciosIds
        });
    }
}

    function verificarH1Unico() {
        let h1s = Array.from(document.getElementsByTagName('h1'));
        let h1sVisibles = h1s.filter(h1 => window.getComputedStyle(h1).display !== 'none');
        const cantidadH1Visibles = h1sVisibles.length;
    
        if (cantidadH1Visibles > 1) {
            const h1Errores = h1sVisibles.map((h1) => {
                const errorId = Math.random().toString(36).substring(7);
                h1.dataset.wcagErrorId = errorId;
                return `❌ Error: Se encontró un <h1> visible adicional.`;
            });
            const h1Ids = h1sVisibles.map(h1 => h1.dataset.wcagErrorId);
    
            erroresDetectados.push({
                titulo: "<h1> único",
                errores: [`Se encontraron ${cantidadH1Visibles} etiquetas <h1> visibles en la página (se espera solo una).`].concat(h1Errores),
                elementIds: h1Ids
            });
        }
    }

    buscarEtiquetasP();
    contarEtiquetas();
    evaluarEtiquetaSmall();
    contarEtiquetasI();
    listarListasVacias();
    verificarEncabezadosVacios();
    verificarEncabezadosTablaVacios();
    verificarH1Unico();
    buscarDivsSinEtiquetaInterior();
    buscarSpansSinCondicion();

    return erroresDetectados;
}

function mostrarErroresEnPopup(errores) {
    let contenedorErrores = document.getElementById('errores');
    contenedorErrores.innerHTML = '';

    if (errores.length > 0) {
        errores.forEach(error => {
            let encabezado = document.createElement('h3');
            encabezado.textContent = `Resultados de la función ${error.titulo}`;
            contenedorErrores.appendChild(encabezado);

            if (error.errores && Array.isArray(error.errores) && error.errores.length > 0) {
                let cantidadMostrada = false;
                let lista = document.createElement('ul');

                error.errores.forEach((errorMsg, index) => {
                    if (!cantidadMostrada && errorMsg.startsWith('Se encontraron')) {
                        let cantidadParrafo = document.createElement('p');
                        cantidadParrafo.textContent = errorMsg;
                        // Añade la clase aquí
                        cantidadParrafo.classList.add('number__message');
                        contenedorErrores.appendChild(cantidadParrafo);
                        cantidadMostrada = true;
                    } else {
                        let li = document.createElement('li');
                        li.textContent = errorMsg;
                        li.classList.add('error');
                        if (error.elementIds && Array.isArray(error.elementIds) && error.elementIds[index - (cantidadMostrada ? 1 : 0)]) {
                            li.dataset.wcagErrorId = error.elementIds[index - (cantidadMostrada ? 1 : 0)];
                        }
                        lista.appendChild(li);
                    }
                });

                if (lista.children.length > 0) {
                    contenedorErrores.appendChild(lista);
                }
            }

            if (error.resumen) {
                let resumenParrafo = document.createElement('p');
                resumenParrafo.textContent = error.resumen;
                resumenParrafo.classList.add('number__message');
                contenedorErrores.appendChild(resumenParrafo);
            }
        });
    } else {
        contenedorErrores.innerHTML = '<li class="mensaje-exito">✅Éxito: No se encontraron errores.</li>';
    }
}