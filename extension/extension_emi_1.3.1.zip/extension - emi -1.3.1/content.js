// content.js
console.log("Content script ejecutándose.");

chrome.runtime.onMessage.addListener(function (message, _sender, _sendResponse) {
    console.log("Mensaje recibido en content:", message);

    if (message.tipo === "resaltarElementosError" && Array.isArray(message.elementIds)) {
        message.elementIds.forEach(errorId => {
            const elements = document.querySelectorAll(`[data-wcag-error-id="${errorId}"]`);
            elements.forEach(element => {
                if (message.activar) {
                    element.classList.add('resaltado-error');
                } else {
                    element.classList.remove('resaltado-error');
                }
            });
        });
    }
});
